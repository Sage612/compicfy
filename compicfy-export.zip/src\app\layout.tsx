import type { Metadata } from 'next'
import { GeistSans } from 'geist/font/sans'
import { GeistMono } from 'geist/font/mono'
import { ThemeProvider } from '@/components/layout/ThemeProvider'
import { Toaster } from 'sonner'
import { CookieBanner } from '@/components/ui/CookieBanner'
import './globals.css'

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL ?? 'https://compicfy.com'

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title: {
    default:  'Compicfy — Find your next obsession',
    template: '%s | Compicfy',
  },
  description: 'Community-driven recommendations for manga, manhwa, manhua, and webtoons. Discover, vote, review, and share your favorite comics.',
  keywords: ['manga', 'manhwa', 'manhua', 'webtoon', 'comics', 'recommendations', 'community'],
  authors:  [{ name: 'Compicfy' }],
  creator:  'Compicfy',
  openGraph: {
    type:        'website',
    locale:      'en_US',
    url:         SITE_URL,
    siteName:    'Compicfy',
    title:       'Compicfy — Find your next obsession',
    description: 'Community-driven recommendations for manga, manhwa, manhua, and webtoons.',
    images: [{ url: '/og-image.png', width: 1200, height: 630, alt: 'Compicfy' }],
  },
  twitter: {
    card:        'summary_large_image',
    title:       'Compicfy — Find your next obsession',
    description: 'Community-driven recommendations for manga, manhwa, manhua, and webtoons.',
    images:      ['/og-image.png'],
  },
  robots: {
    index:     true,
    follow:    true,
    googleBot: { index: true, follow: true },
  },
}

const websiteJsonLd = {
  '@context': 'https://schema.org',
  '@type':    'WebSite',
  name:       'Compicfy',
  url:         SITE_URL,
  description: 'Community-driven manga, manhwa, manhua, and webtoon recommendations.',
  publisher: {
    '@type': 'Organization',
    name:    'Compicfy',
    url:      SITE_URL,
    logo: {
      '@type':  'ImageObject',
      url:      `${SITE_URL}/icons/icon-192.png`,
      width:    192,
      height:   192,
    },
  },
  potentialAction: {
    '@type':  'SearchAction',
    target: {
      '@type':     'EntryPoint',
      urlTemplate: `${SITE_URL}/browse?q={search_term_string}`,
    },
    'query-input': 'required name=search_term_string',
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, viewport-fit=cover, interactive-widget=resizes-visual"
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(websiteJsonLd) }}
        />
      </head>
      <body className={`${GeistSans.variable} ${GeistMono.variable} antialiased bg-background text-foreground`}>
        <ThemeProvider attribute="class" defaultTheme="system" enableSystem disableTransitionOnChange>
          {children}
          <Toaster richColors position="top-right" />
          <CookieBanner />
        </ThemeProvider>
      </body>
    </html>
  )
}