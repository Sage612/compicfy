import { createClient } from '@/lib/supabase/server'
import { Suspense } from 'react'
import { FilterBar } from '@/components/recommendations/FilterBar'
import { FeaturedCarousel } from '@/components/recommendations/FeaturedCarousel'
import { HorizontalSection } from '@/components/recommendations/HorizontalSection'
import { ComicGridClient } from '@/components/recommendations/ComicGridClient'
import { ShieldAlert, BookOpen, ArrowLeft } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import type { Recommendation } from '@/types/database.types'
import type { SupabaseClient } from '@supabase/supabase-js'
import type { Metadata } from 'next'

export const metadata: Metadata = { title: '18+ Comics' }

interface SearchParams {
  q?:      string
  type?:   string
  genre?:  string
  status?: string
  sort?:   string
}

interface Props {
  searchParams: Promise<SearchParams>
}

const PAGE_SIZE     = 24
const ADULT_RATINGS = ['adult', 'mature'] as const

async function getFeatured(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).in('content_rating', ADULT_RATINGS).order('daily_votes', { ascending: false }).limit(8)
  return (data as Recommendation[]) ?? []
}

async function getTrending(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).in('content_rating', ADULT_RATINGS).order('daily_votes', { ascending: false }).limit(12)
  return (data as Recommendation[]) ?? []
}

async function getRecent(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).in('content_rating', ADULT_RATINGS).order('created_at', { ascending: false }).limit(12)
  return (data as Recommendation[]) ?? []
}

async function getNewThisWeek(s: SupabaseClient) {
  const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString()
  const { data } = await s
    .from('recommendations')
    .select('*')
    .eq('is_approved', true)
    .in('content_rating', ADULT_RATINGS)
    .gte('created_at', sevenDaysAgo)
    .order('score', { ascending: false })
    .limit(12)
  return (data as Recommendation[]) ?? []
}

async function getAdminPicks(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).eq('is_featured', true).in('content_rating', ADULT_RATINGS).order('featured_at', { ascending: false }).limit(12)
  return (data as Recommendation[]) ?? []
}

async function getCommunityFavourites(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).in('content_rating', ADULT_RATINGS).order('score', { ascending: false }).limit(12)
  return (data as Recommendation[]) ?? []
}

async function getHiddenGems(s: SupabaseClient) {
  const { data } = await s.from('recommendations').select('*').eq('is_approved', true).in('content_rating', ADULT_RATINGS).order('save_count', { ascending: false }).limit(12)
  return (data as Recommendation[]) ?? []
}

async function getYouMightLike(s: SupabaseClient, userId: string) {
  const { data } = await (s as any).rpc('get_personalized_recommendations', {
    p_user_id:         userId,
    p_exclude_id:      null,
    p_limit:           20,
    p_content_ratings: ['mature', 'adult'],
  })
  let results = (data as Recommendation[]) ?? []
  results = results.filter(r => (r as any).user_id !== userId)
  return results.slice(0, 12)
}

async function getInitialGrid(s: SupabaseClient, params: SearchParams) {
  const { data } = await (s as any).rpc('search_recommendations', {
    p_query:  params.q      || null,
    p_type:   params.type   || null,
    p_genre:  params.genre  || null,
    p_status: params.status || null,
    p_sort:   params.sort   ?? 'score',
    p_adult:  true,
    p_limit:  PAGE_SIZE,
    p_offset: 0,
  })

  const { count } = await s
    .from('recommendations')
    .select('*', { count: 'exact', head: true })
    .eq('is_approved', true)
    .in('content_rating', ADULT_RATINGS)

  return {
    items: (data as Recommendation[]) ?? [],
    total: count ?? 0,
  }
}

async function getInteractionCount(s: SupabaseClient, userId: string): Promise<number> {
  const [votesRes, savesRes] = await Promise.all([
    s.from('votes').select('*', { count: 'exact', head: true }).eq('user_id', userId),
    s.from('saves').select('*', { count: 'exact', head: true }).eq('user_id', userId),
  ])
  return (votesRes.count ?? 0) + (savesRes.count ?? 0)
}

function hasActiveFilters(p: SearchParams) {
  return !!(p.q || p.type || p.genre || p.status || p.sort)
}

function AccessGate({ title, description, actions }: {
  title:       string
  description: string
  actions:     React.ReactNode
}) {
  return (
    <div className="max-w-md mx-auto px-4 py-24 text-center space-y-5">
      <div className="w-16 h-16 rounded-2xl bg-destructive/10 flex items-center justify-center mx-auto">
        <ShieldAlert size={28} className="text-destructive" />
      </div>
      <h1 className="text-2xl font-black">{title}</h1>
      <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      <div className="flex justify-center gap-3">{actions}</div>
    </div>
  )
}

export default async function AdultBrowsePage({ searchParams }: Props) {
  const params      = await searchParams
  const isFiltering = hasActiveFilters(params)

  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return (
      <AccessGate
        title="Age Restricted"
        description="You must be logged in with adult content enabled to access this section."
        actions={
          <>
            <Link href="/browse">
              <Button variant="outline">Back to Browse</Button>
            </Link>
            <Link href="/login">
              <Button>Log In</Button>
            </Link>
          </>
        }
      />
    )
  }

  const { data: profile } = await supabase
    .from('profiles')
    .select('adult_content_enabled, is_pro, pro_expires_at, role')
    .eq('id', user.id)
    .single()

  const isPro =
    (profile as any)?.role === 'admin' ||
    (profile as any)?.role === 'moderator' ||
    ((profile as any)?.is_pro && (
      !(profile as any)?.pro_expires_at ||
      new Date((profile as any).pro_expires_at) > new Date()
    ))

  const settingsUrl = isPro ? '/pro/settings' : '/dashboard/settings'

  if (!(profile as any)?.adult_content_enabled) {
    return (
      <AccessGate
        title="Adult Content Disabled"
        description="Enable adult content in your profile settings to access this section."
        actions={
          <>
            <Link href="/browse">
              <Button variant="outline">Back to Browse</Button>
            </Link>
            <Link href={settingsUrl}>
              <Button>Go to Settings</Button>
            </Link>
          </>
        }
      />
    )
  }

  const [
    featured,
    trending,
    recent,
    newThisWeek,
    adminPicks,
    communityFavs,
    hiddenGems,
    youMightLike,
    { items, total },
    interactionCount,
  ] = await Promise.all([
    isFiltering ? Promise.resolve([]) : getFeatured(supabase),
    isFiltering ? Promise.resolve([]) : getTrending(supabase),
    isFiltering ? Promise.resolve([]) : getRecent(supabase),
    isFiltering ? Promise.resolve([]) : getNewThisWeek(supabase),
    isFiltering ? Promise.resolve([]) : getAdminPicks(supabase),
    isFiltering ? Promise.resolve([]) : getCommunityFavourites(supabase),
    isFiltering ? Promise.resolve([]) : getHiddenGems(supabase),
    isFiltering ? Promise.resolve([]) : getYouMightLike(supabase, user.id),
    getInitialGrid(supabase, params),
    getInteractionCount(supabase, user.id),
  ])

  const clientParams: Record<string, string> = { adult: 'true' }
  if (params.q)      clientParams.q      = params.q
  if (params.type)   clientParams.type   = params.type
  if (params.genre)  clientParams.genre  = params.genre
  if (params.status) clientParams.status = params.status
  if (params.sort)   clientParams.sort   = params.sort

  return (
    <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">

      {/* Header */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-9 h-9 rounded-xl bg-destructive/10 border border-destructive/20 flex items-center justify-center shrink-0">
            <ShieldAlert size={16} className="text-destructive" />
          </div>
          <div className="min-w-0">
            <h1 className="text-xl font-black tracking-tight leading-tight">18+ Comics</h1>
            <p className="text-muted-foreground text-xs mt-0.5 truncate">
              Adult &amp; mature · opted-in only
            </p>
          </div>
        </div>
        <Link href="/browse" className="shrink-0">
          <Button
            variant="outline"
            size="sm"
            className="gap-1.5 h-8 px-3 text-xs border-border hover:border-primary/40 hover:text-primary transition-colors"
          >
            <ArrowLeft size={12} />
            <span className="hidden sm:inline">All Ages</span>
            <span className="sm:hidden">Back</span>
          </Button>
        </Link>
      </div>

      {/* Warning banner */}
      <div className="flex items-center gap-2.5 px-4 py-2.5 rounded-xl bg-destructive/5 border border-destructive/15">
        <span className="text-sm shrink-0">🔞</span>
        <p className="text-xs text-muted-foreground leading-relaxed">
          Adult &amp; mature content approved by admins.{' '}
          <Link href={settingsUrl} className="text-primary hover:underline font-medium">
            Disable in Settings
          </Link>
        </p>
      </div>

      {/* Featured Carousel */}
      {!isFiltering && featured.length > 0 && (
        <Suspense fallback={<div className="h-[280px] sm:h-[360px] rounded-2xl bg-muted animate-pulse" />}>
         <FeaturedCarousel recommendations={featured} adminFeaturedIds={new Set()} />
        </Suspense>
      )}

      {/* Horizontal Sections */}
      {!isFiltering && (
        <div className="space-y-8">
          {trending.length > 0      && <HorizontalSection title="Trending Today"        emoji="🔥" recommendations={trending}     viewAllHref="/browse/adult?sort=trending" />}
          {newThisWeek.length > 0   && <HorizontalSection title="New This Week"         emoji="🆕" recommendations={newThisWeek}  viewAllHref="/browse/adult?sort=recent"   />}
          {recent.length > 0        && <HorizontalSection title="Recently Added"        emoji="✨" recommendations={recent}       viewAllHref="/browse/adult?sort=recent"   />}
          {adminPicks.length > 0    && <HorizontalSection title="Admin Picks"           emoji="👑" recommendations={adminPicks}                                              />}
          {communityFavs.length > 0 && <HorizontalSection title="Community Favourites"  emoji="❤️" recommendations={communityFavs} viewAllHref="/browse/adult?sort=score"   />}
          {hiddenGems.length > 0    && <HorizontalSection title="Hidden Gems"           emoji="💎" recommendations={hiddenGems}                                              />}
          {youMightLike.length > 0  && <HorizontalSection title="You Might Like"        emoji="🎯" recommendations={youMightLike}                                            />}
        </div>
      )}

      {/* All 18+ divider */}
      {!isFiltering && (
        <div className="relative flex items-center gap-4 py-2">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent via-border to-border" />
          <div className="flex items-center gap-2 px-4 py-2 rounded-lg border border-border bg-card shrink-0">
            <BookOpen size={13} className="text-muted-foreground" />
            <span className="text-xs font-black uppercase tracking-widest text-muted-foreground">All 18+ Comics</span>
          </div>
          <div className="flex-1 h-px bg-gradient-to-l from-transparent via-border to-border" />
        </div>
      )}

      {/* Filter Bar */}
      <Suspense fallback={<div className="h-24 bg-muted/30 rounded-xl animate-pulse" />}>
        <FilterBar adult={true} />
      </Suspense>

      {/* Comic Grid */}
      <ComicGridClient
        initialItems={items}
        initialTotal={total}
        searchParams={clientParams}
        apiPath="/api/recommendations"
        userId={user.id}
        interactionCount={interactionCount}
        contentRatings={['mature', 'adult']}
        isPro={isPro}
      />

    </div>
  )
}