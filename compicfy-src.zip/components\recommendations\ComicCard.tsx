'use client'

import Link from 'next/link'
import { ThumbsUp, MessageSquare, Bookmark, TrendingUp, Bot } from 'lucide-react'
import { cn } from '@/lib/utils'
import { formatNumber } from '@/lib/utils/format'
import { TYPE_META, DEFAULT_TYPE_META, resolveStatusMeta } from '@/lib/utils/constants'
import type { Recommendation } from '@/types/database.types'

interface ComicCardProps {
  recommendation: Recommendation
  className?:     string
  showGenres?:    boolean
}

// Uses reviewed_at (approval timestamp) instead of created_at (submission
// timestamp) — same fix as getNewThisWeek on the browse pages. A comic that
// sat in the approval queue for days shouldn't lose its "new" badge before
// it's even been approved. No reviewed_at on record → no badge, rather than
// silently falling back to created_at and reopening the same bug.
function isNewThisWeek(reviewedAt: string | null): boolean {
  if (!reviewedAt) return false
  return Date.now() - new Date(reviewedAt).getTime() < 7 * 24 * 60 * 60 * 1000
}

// ── Proxy helper — routes all cover images through our proxy ──────
function proxyCover(url: string | null | undefined): string | null {
  if (!url) return null
  // data: URIs are self-contained — pass through untouched
  if (url.startsWith('data:')) return url
  // Already a relative/local URL — no need to proxy
  if (url.startsWith('/')) return url
  // Already proxied
  if (url.includes('/api/image-proxy')) return url
  return `/api/image-proxy?url=${encodeURIComponent(url)}`
}

export function ComicCard({ recommendation: rec, className, showGenres = true }: ComicCardProps) {
  const accent    = TYPE_META[rec.type as keyof typeof TYPE_META] ?? DEFAULT_TYPE_META
  const status    = resolveStatusMeta(rec.status, (rec as any).translation_status)
  const score     = rec.score ?? (rec.upvotes - rec.downvotes)
  const isNew     = isNewThisWeek(rec.reviewed_at)
  const coverSrc  = proxyCover(rec.cover_url)

  // System-submitted flag — covers auto-submitter and any future system accounts
  const isSystemSubmitted = rec.is_ai_generated && rec.ai_model === 'auto-submitter'

  return (
    <Link
      href={`/comic/${rec.id}`}
      className={cn(
        '@container/card group relative flex flex-col rounded-xl overflow-hidden',
        'border border-border bg-card',
        'hover:border-transparent hover:shadow-xl',
        accent.glow,
        'transition-all duration-300',
        className
      )}
    >
      {/* ── Accent bar — left edge ── */}
      <div className={cn(
        'absolute left-0 top-0 bottom-0 w-[3px] z-10 transition-all duration-300 group-hover:w-1',
        accent.bar
      )} />

      {/* ── Cover ── */}
      <div className="relative aspect-[3/4] overflow-hidden bg-muted">
        {coverSrc ? (
          <img
            src={coverSrc}
            alt={`Cover art for ${rec.title}`}
            title={rec.title}
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.04]"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-muted">
            <span className="text-3xl opacity-20">📖</span>
          </div>
        )}

        {/* Scrim — only bottom */}
        <div className="absolute inset-x-0 bottom-0 h-1/2 bg-gradient-to-t from-black/80 to-transparent" />

        <div className="absolute top-1.5 left-2.5 @min-[150px]/card:top-2 @min-[150px]/card:left-3.5 z-10">
          <span className={cn(
            'inline-flex items-center px-1 py-0.5 rounded text-[7px] @min-[150px]/card:px-1.5 @min-[150px]/card:text-[9px] font-black uppercase tracking-wider border',
            accent.badge
          )}>
            {rec.type}
          </span>
        </div>

        {/* ── Top-right: NEW or score ── */}
        <div className="absolute top-1.5 right-1.5 @min-[150px]/card:top-2 @min-[150px]/card:right-2 z-10">
          {isNew ? (
            <span className="inline-flex items-center px-1 py-0.5 rounded text-[7px] @min-[150px]/card:px-1.5 @min-[150px]/card:text-[9px] font-black bg-emerald-500 text-white">
              NEW
            </span>
          ) : score > 0 ? (
            <span className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded text-[7px] @min-[150px]/card:px-1.5 @min-[150px]/card:text-[9px] font-black bg-black/60 backdrop-blur-sm text-white/90">
              <TrendingUp size={6} className="@min-[150px]/card:hidden" />
              <TrendingUp size={7} className="hidden @min-[150px]/card:block" />
              {formatNumber(score)}
            </span>
          ) : null}
        </div>

        {/* ── SYS badge ── */}
        {isSystemSubmitted && (
          <div className="absolute bottom-6 left-2.5 @min-[150px]/card:bottom-7 @min-[150px]/card:left-3.5 z-10">
            <span
              title="Submitted by ComPicfy system"
              className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded text-[7px] @min-[150px]/card:text-[8px] font-black bg-black/50 backdrop-blur-sm text-white/60 border border-white/10"
            >
              <Bot size={6} />
              SYS
            </span>
          </div>
        )}

        {/* ── Bottom title ── */}
        <div className="absolute inset-x-0 bottom-0 px-3 pt-4 pb-2.5 z-10">
          <h3 className="text-white font-black text-[11px] leading-snug line-clamp-2 drop-shadow-sm">
            {rec.title}
          </h3>
        </div>
      </div>

     
      <div className="px-3 pt-2 pb-2.5 space-y-1.5 pl-4 @container/meta">

        <div className="flex items-center justify-between gap-1 min-w-0">
          <span className={cn('text-[9px] font-bold shrink-0', status.color)}>
            {status.label}
          </span>
          {showGenres && rec.genres?.length > 0 && (
            <span className="hidden @min-[130px]/card:block text-[9px] text-muted-foreground/60 truncate min-w-0 max-w-[60%] text-right">
              {rec.genres.slice(0, 2).join(' · ')}
            </span>
          )}
        </div>

        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 @sm/card:gap-x-2.5 text-[9px] text-muted-foreground">
          <span className="flex items-center gap-0.5 shrink-0">
            <ThumbsUp size={8} className="text-emerald-500/70 shrink-0" />
            {formatNumber(rec.upvotes)}
          </span>
          <span className="flex items-center gap-0.5 shrink-0">
            <MessageSquare size={8} className="text-amber-500/70 shrink-0" />
            {formatNumber(rec.review_count)}
          </span>
          <span className="flex items-center gap-0.5 shrink-0">
            <Bookmark size={8} className="text-blue-500/70 shrink-0" />
            {formatNumber(rec.save_count)}
          </span>
        </div>

        {/* Cover credit — always shown; both the narrow horizontal-carousel
            cards and the wider grid cards need attribution visible. */}
        {rec.cover_url && (
          <p className="text-[8px] text-muted-foreground/40 truncate">
            © {rec.author ?? 'respective rights holder'}
          </p>
        )}
      </div>

      {/* ── Hover shimmer ── */}
      <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none bg-gradient-to-br from-white/[0.03] to-transparent" />
    </Link>
  )
}